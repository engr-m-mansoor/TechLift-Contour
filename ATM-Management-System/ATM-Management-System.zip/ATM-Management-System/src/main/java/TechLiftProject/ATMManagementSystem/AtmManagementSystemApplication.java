package TechLiftProject.ATMManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtmManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtmManagementSystemApplication.class, args);
	}

}
