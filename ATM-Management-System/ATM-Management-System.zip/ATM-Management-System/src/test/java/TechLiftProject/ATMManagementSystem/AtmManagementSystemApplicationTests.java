package TechLiftProject.ATMManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtmManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
