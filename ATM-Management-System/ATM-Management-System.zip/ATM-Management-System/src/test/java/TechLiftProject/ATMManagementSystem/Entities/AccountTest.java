package TechLiftProject.ATMManagementSystem.Entities;

import static org.junit.jupiter.api.Assertions.*;

class AccountTest {

}