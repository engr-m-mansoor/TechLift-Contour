package TechLiftProject.ATMManagementSystem;

public class BalanceCheckTest {
}
